package SQL.BD1.Proyecto.dto;
public class DTOjugadores {
    /*
    //Data transfer object
    //TransferObject es una representacion en objeto de lo que esta
    //en la base de datos
     */


    private int dni;
    private String nombre;
    private double sueldo;
    private String sexo;
    private String numDorsal;
    private int equipos_id;


    public DTOjugadores(int dni, String nombre, double sueldo, String sexo, String numDorsal, int equipos_id) {
        this.dni = dni;
        this.nombre = nombre;
        this.sueldo = sueldo;
        this.sexo = sexo;
        this.numDorsal = numDorsal;
        this.equipos_id = equipos_id;
    }

    public int getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getNumDorsal() {
        return numDorsal;
    }

    public void setNumDorsal(String numDorsal) {
        this.numDorsal = numDorsal;
    }

    public int getEquipos_id() {
        return equipos_id;
    }

    public void setEquipos_id(int equipos_id) {
        this.equipos_id = equipos_id;
    }

    @Override
    public String toString() {
        return "Persona: id = " + dni + " | nombre = " + nombre + " | sueldo = " + sueldo + " | sexo = " + sexo + " | numDorsal = " + numDorsal + " | equipos_id = " + equipos_id;
    }
}
