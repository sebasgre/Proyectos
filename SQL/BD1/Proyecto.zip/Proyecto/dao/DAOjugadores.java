package SQL.BD1.Proyecto.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import Java.Programacion3.Lista.Lista2;
import SQL.BD1.Proyecto.dal.DSConexion;
import SQL.BD1.Proyecto.dto.DTOjugadores;

public class DAOjugadores {
    // private DSConexion conexion;

    // patron dao para acceder a la base de datos
    public Lista2<DTOjugadores> getTodos() {
        Lista2<DTOjugadores> resultado = null;
        String query = "select dni, nombre, sueldo, sexo, numDorsal, equipos_id from jugadores";
        ResultSet rs = null;
        try {
            DSConexion conexion = DSConexion.getOrCreate();
            rs = conexion.ejecutarConsulta(query);
        } catch (SQLException e) {
            System.out.println("No pudo ejecutar consulta");
            return resultado;
        }
        try {
            resultado = new Lista2<DTOjugadores>();
            while (rs.next()) {
                int _dni = rs.getInt("dni");
                String _nombre = rs.getString("nombre");
                double _sueldo = rs.getDouble("sueldo");
                String _sexo = rs.getString("sexo");
                String _numDorsal = rs.getString("numDorsal");
                int _equipos_id = rs.getInt("equipos_id");
                // recuerpo el entero como entero del iterador y recupero un string de la
                // columna nombre
                resultado.add(new DTOjugadores(_dni, _nombre, _sueldo, _sexo, _numDorsal, _equipos_id));
            }
        } catch (SQLException e) {
            System.out.println("Error recuperando datos del resultset: " + e.getMessage());
        }
        return resultado;
    }

    public DTOjugadores getPorId(int id) {
        DTOjugadores resultado = null;
        String query = "select dni, nombre, sueldo, sexo, numDorsal, equipos_id from jugadores where dni = " + id;

        ResultSet rs = null;
        try {
            DSConexion conexion = DSConexion.getOrCreate();
            rs = conexion.ejecutarConsulta(query);
        } catch (SQLException e) {
            System.out.println("No pudo ejecutar consulta");
            return resultado;
        }
        try {
            if (rs.next()) {
                int _dni = rs.getInt("dni");
                String _nombre = rs.getString("nombre");
                double _sueldo = rs.getDouble("sueldo");
                String _sexo = rs.getString("sexo");
                String _numDorsal = rs.getString("numDorsal");
                int _equipos_id = rs.getInt("equipos_id");
                // recuerpo el entero como entero del iterador y recupero un string de la
                // columna nombre
                resultado = new DTOjugadores(_dni, _nombre, _sueldo, _sexo, _numDorsal, _equipos_id);
            }
        } catch (SQLException e) {
            System.out.println("Error recuperando datos del resultset: " + e.getMessage());
        }
        return resultado;
    }

    public void actualizar(DTOjugadores p) {

        String query = "update jugadores set nombre = '" + p.getNombre() + "' where dni = " + p.getDni();
        try {
            DSConexion conexion = DSConexion.getOrCreate();
            conexion.ejecutarComando(query);
        } catch (SQLException e) {
            System.out.println("No pudo ejecutar consulta");
        }
    }

    public void insertar(DTOjugadores p) {

        String query = "insert into jugadores (dni, nombre, sueldo, sexo, numDorsal, equipos_id) values (" + p.getDni()
                + ",'" + p.getNombre() + "'," + p.getSueldo() + "," + p.getSexo() + "," + p.getSexo() + ",'"
                + p.getNumDorsal() + "'," + p.getEquipos_id() + ")";

        try {
            DSConexion conexion = DSConexion.getOrCreate();
            conexion.ejecutarComando(query);
        } catch (SQLException e) {
            System.out.println("No pudo ejecutar consulta");
        }
    }

    public void eliminar(DTOjugadores p) {

        String query = "delete from jugadores where dni = " + p.getDni();

        try {
            DSConexion conexion = DSConexion.getOrCreate();
            conexion.ejecutarComando(query);
        } catch (SQLException e) {
            System.out.println("No pudo ejecutar consulta");
        }
    }

}
