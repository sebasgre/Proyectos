package Java.Programacion3.practico6;

public interface Identificable {
    public String getId();
}
