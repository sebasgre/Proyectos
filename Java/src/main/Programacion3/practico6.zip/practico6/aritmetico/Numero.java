package Programacion3.practico6.aritmetico;

public class Numero extends ElementoAritmetico {
    private double valor;

    public Numero(double v) {
        valor = v;
    }

    public double getValor() {
        return valor;
    }
}
