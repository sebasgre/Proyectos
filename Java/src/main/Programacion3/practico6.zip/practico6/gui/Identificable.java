package Programacion3.practico6.gui;

public interface Identificable {
    public String getId();
}
