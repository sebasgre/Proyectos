package SQL.BD1.Proyecto.gui;

public interface Lista<T> {

}
