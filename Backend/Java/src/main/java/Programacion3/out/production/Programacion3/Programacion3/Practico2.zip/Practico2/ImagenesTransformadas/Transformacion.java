package Programacion3.Practico2.ImagenesTransformadas;
import Programacion3.Practico2.Imagenes.Modelo;

public abstract class Transformacion {
    protected Modelo modeloBase;

    public abstract void hacer1();
    public abstract void hacer2();
    public abstract void hacer3();
}
