package Programacion3.practico7y8.modelo;

public interface Identificable {
    public String getId();
}
