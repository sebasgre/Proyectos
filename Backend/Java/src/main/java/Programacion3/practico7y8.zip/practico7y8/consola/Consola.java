package Programacion3.practico7y8.consola;

import Programacion3.practico7y8.gui.FrameArbol;

public class Consola {
    public static void main(String[] args) {
        FrameArbol frame = new FrameArbol();
        frame.setVisible(true);
    }
}
