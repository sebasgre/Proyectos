package Programacion3.practico7y8.gui;

import java.awt.*;

public interface IDibujo {

    public void dibujar(Graphics g);
}
