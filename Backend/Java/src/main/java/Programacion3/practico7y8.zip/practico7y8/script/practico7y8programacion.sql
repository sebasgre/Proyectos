CREATE DATABASE practico8;

use practico8;

CREATE TABLE expresiones(
    nombre VARCHAR(20) PRIMARY KEY,
    expresion VARCHAR(1000) NOT NULL
);

