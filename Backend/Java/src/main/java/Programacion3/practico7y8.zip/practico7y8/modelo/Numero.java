package Programacion3.practico7y8.modelo;

public class Numero extends ElementoAritmetico {

    private double valor;

    public Numero(double valor) {
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }
}
