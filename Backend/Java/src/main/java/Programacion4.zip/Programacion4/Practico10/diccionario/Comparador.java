package Programacion4.Practico10.diccionario;

public interface Comparador<TKEY> {

    boolean esIgual(TKEY key1, TKEY key2);
}
