package Programacion4.Recuperatorio;

import java.util.Scanner;

public class Rec17 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int time = sc.nextInt();
        System.out.println(time*2 + " minutos");
    }
}
