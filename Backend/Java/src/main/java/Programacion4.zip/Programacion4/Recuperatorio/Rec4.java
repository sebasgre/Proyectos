package Programacion4.Recuperatorio;

import java.util.Scanner;

public class Rec4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt();
        int num2 = sc.nextInt();
        int soma = num1 + num2;
        System.out.println("SOMA = " + soma);
    }
}
