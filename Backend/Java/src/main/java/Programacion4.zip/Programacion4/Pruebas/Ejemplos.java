package Programacion4.Pruebas;

import java.util.Scanner;

public class Ejemplos {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        System.out.printf("%.4f",Math.PI);
    }
}
